<!-- this part will represent the php code part that isshow the spicific product information -->
<?php
include "php/show.php";// let the show php file that is in the php to be included in this php file

    if ($row == true) {// if all the element available in the row from the table make from it object
    $product = new Product(
    $row['id'],
    $row['name'],
    $row['category'],
    $row['description'],
    $row['price'],
    $row['rating'],
    $row['image'],
    $row['quantity']
    );

?>


<!-- this part will represent the html code that will contauin to show the detail of the spicific product -->

    <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <title>
               <?php 
                    echo $product->name 
               ?>
            </title>
        </head>

        <?php
            include "components/header.php";// include the header here that using include to include it from the page
        ?>
        <body>

            <article class="product">

                <?php 
                echo  $product->displayProductPage();// display the product page that contains its information 
                ?>
            </article>

        </body>
            <?php
            include "components/footer.php";// include the footer here that using include to include it from the page
            ?>
    </html>
<?php
        } else {// else if there is element not set in the row then the product not foind
            if (!$row) {
                echo "The product choosen not found!!!!!!";// print out that the product choosen not found
            }

        }
?>

