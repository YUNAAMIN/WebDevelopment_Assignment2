<!-- this part will represent the php code part that is to insert and add  -->

<!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="UTF-8">
            <title>update Product Record Page</title><!--this will represent the title of the page-->
        </head>
        <?php
        include "components/header.php";// include the header here that using include to include it from the page
        ?>

        <body>

            <h2>Product Record:</h2><!-- hedear for the product record-->

            <form method="post" action="php/add.php" enctype="multipart/form-data"><!--form that representmethod post that will send action to add.php that is in the php folder -->

                <label for="productName">Product Name:</label><!-- lable for product name -->
                <input type="text" id="name" name="name" ><br><br><!-- input text number for name -->

                <label for="category">Category:</label><!-- lable for product category -->
                <select id="category" name="category" required><!-- input type select from combox for category -->
                    <option value="" selected>Select Category</option>
                    <option value="Formal Shirt">Formal Shirt</option>
                    <option value="Sweater">Sweater</option>
                    <option value="Trousers">Trousers</option>
                    <option value="Dress">Dress</option>
                    <option value="T-shirt">T-shirt</option>
                    <option value="Jeans">Jeans</option>
                    <option value="Skirt">Skirt</option>
                    <option value="Blouse">Blouse</option>
                </select>
                <br><br>

                <label for="price">Price:</label><!-- lable for product price -->
                <input type="number" id="price" name="price" ><br><br><!-- input type number for price -->

                <label for="quantity">Quantity:</label><!-- lable for product quantity -->
                <input type="number" id="quantity" name="quantity" ><br><br><!-- input type number for quantity -->

                <label for="rating">Rating:</label><!-- lable for product rating -->
                <input type="number" id="rating" name="rating"  min="1" max="5"><br><br><!-- input type number for rating -->

                <label for="description">Description:</label><!-- lable for product description -->
                <textarea id="description" name="description" rows="6" cols="60">

            </textarea><br><br>

                <label for="productPhoto">Product Photo:</label><!-- lable for product picture -->
                <input type="file" id="image" name="image" accept="image/jpeg"><br><br><!-- input type file for image -->

                <input type="submit" value="add"><!-- input type submit  for add action -->
            </form>

        </body>
                <?php
                include "components/footer.php";// include the footer here that using include to include it from the page
                ?>
    </html>
