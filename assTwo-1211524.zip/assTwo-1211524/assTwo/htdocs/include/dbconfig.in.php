<?php

namespace Config;

const DB_HOST = 'localhost';
const DB_NAME = 'web1211524_clothingStore';
const DB_USER = 'web1211524_dbuser';
const DB_PASS = '45$Rmagy9T';
const DB_CHARSET = 'utf8mb4';

const DSN = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

