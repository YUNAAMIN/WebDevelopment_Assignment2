<!-- this will represents the pdo database that will take confoigration -->

<?php
require 'dbconfig.in.php';// require the data base configration file to use its element here

try {// use try and catch to handle the error that may occure 
    $pdo = new PDO(Config\DSN, Config\DB_USER, Config\DB_PASS);// create new pdo object 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {//handle the pdo exception
    die(" the database couldnt connect to it : " . $e->getMessage());
}


