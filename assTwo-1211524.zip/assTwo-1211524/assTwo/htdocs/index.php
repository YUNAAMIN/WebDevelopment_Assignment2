<!--this class is index class thewill be importent for the filters and searching  and also to display the table content of the product-->
<?php
require "php/index.php";// make the content of the index that in php foldr is required here
?>

<!--html part to represents the filter part and also the searching and displaying the table -->

<!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Products Table Result</title>
    </head>

    <?php
    include "components/header.php";//include the header here that using include to include it from the page
    ?>

    <body>
        <Section><!--section to add product from it -->
        To add a new product, click on the following link: <a href="insert.php">Add Product</a><br><br>Or use the actions below to edit or delete a products record
        </Section>

        <!-- serach section that will search and filter from it  Section -->

        <fieldset style="width: 100%; border: 1px solid black;"><!-- field set for the form  -->
            <legend style="text-align: left;">Advanced Product Search</legend><!-- legent to drawn line   -->

        <Section>
            <form action="" method="get">
                <!-- input type text that will take the value that am gonna search for -->
                <input type="text" placeholder="Search product name" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">

                    <span><!-- span to print them behind each others   -->
                            <input type="radio"  name="type" value="name"
                             <?php if (isset($_GET['type']) && $_GET['type'] == 'name') {//if the clicked radio button value is equals to name 
                                            echo 'checked';
                                        } ?> />


                            <label for="huey">Name</label>
                            <input type="radio"  name="type" value="price"
                              <?php if (isset($_GET['type']) && $_GET['type'] == 'price') {//if the clicked radio button value is equals to price
                                            echo 'checked';
                                        } ?> />


                            <label for="dewey">Price</label>
                            <input type="radio"  name="type" value="category"
                              <?php if (isset($_GET['type']) && $_GET['type'] == 'category') {//if the clicked radio button value is equals to category
                                            echo 'checked';
                                        } ?> />


                            <label for="louie">Category</label><!--label to the category -->
                    </span>

                <select id="category" name="category" ><!--combobox for the catigoory selection -->
                    <option value="" selected>Select Category</option><!--option for category -->
                    <option value="Formal Shirt">Formal Shirt</option><!--option for category -->
                    <option value="Sweater">Sweater</option><!--option for category -->
                    <option value="Trousers">Trousers</option><!--option for category -->
                    <option value="Dress">Dress</option><!--option for category -->
                    <option value="T-shirt">T-shirt</option><!--option for category -->
                    <option value="Jeans">Jeans</option><!--option for category -->
                    <option value="Skirt">Skirt</option><!--option for category -->
                    <option value="Blouse">Blouse</option><!--option for category -->
                </select>
                <button type="submit">Filter</button><!--submit button that represent the filter action in the search  -->
            </form>
            <br>
        </Section>

        <!--here is the third section that will contains the tabel in it  -->
            <Section>
            <table border="1" >
                <caption ><strong>Products Table Result </strong></caption><!--title of the table -->

                <tr><!--here is the titles for the table -->
                    <th>Product Image</th>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Actions</th>
                </tr>

                <?php
                    foreach ($products as $productinfo) {// to walk througth the products 
                        $productinfo->displayInTable();// display them on the table with the information
                    }
                ?>
            </table>
            </Section>
        </fieldset>

    </body>

        <?php
            include "components/footer.php";// include the footer here that using include to include it from the page
        ?>

</html>
