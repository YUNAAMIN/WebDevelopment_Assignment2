<!-- this will represents the footer part for each page that i will use-->
<header>
<section>
<figure>
    <a href="index.php">
        <img id="icon" src="./storage/images/love.png" alt="EClothing" width="100" height="100">
        <figure>
        <figcaption>
    </a>

    <h1>KOKORU</h1>
    </figcaption>
    </section>
    <hr>
    <nav>
        <a href="index.php">Home</a>
        <a href="insert.php">Add</a>
        <a href="edit.php">Edit</a>
        <a href="php/delete.php">Delete</a>
        <a href="php/show.php">Show</a>


    </nav>
    <hr>
</header>
