<!-- this will represents the footer part for each page that i will use-->
<footer>
    <hr>
    <p>Last Updated:<time>April 4, 2024</time> </p>
    <address>
        EClothing.ps<br>
        Ramallah, Al-Beirah satehMar7aba, 12345
    </address>
    <p>
        <a href="tel:+0597908705">(+970)597908705</a> |
        <a href="mailto:yunanawahdah2003@gmail.com">yunanawahdah2003@gmail.com</a> |
        <a href="./../../../ass/ass1/communicate.html">Contact Us</a>
    </p>
</footer>
