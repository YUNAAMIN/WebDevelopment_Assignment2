<?php
    namespace Controller;
    
    require __DIR__ . '/../include/database.php';  //require the date base here 
    
    $id = isset($_GET['id']) ? $_GET['id'] : null;// the value get id other wise null
    if (!$id) {// if the id not have id 
            echo "there is no product specified!!!!.";// print out thet the product not specified
            exit;// exit
        }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {//the request method to post
        $name = $_POST['name'];// post the value of name
        $description = $_POST['description'];// post the value of description
        $price = $_POST['price'];// post the value of price
        $image = $_FILES['image']['name'];// post the value of image
        $imageTemp = $_FILES['image']['tmp_name'];// post the value of image
        $quantity = $_POST['quantity'];// post the value of quantity
    
        try {// pdo to select the values
            $stmt = $pdo->prepare("SELECT image FROM products WHERE id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $product = $stmt->fetch();
    
           if (!$product) {//if there is no product 
                echo " The Product not found!!!.";// print out that there is no product
                exit;//exit
        }
    
            $currentImage = $product['image'];

            if (!empty($image) && move_uploaded_file($imageTemp, "../storage/images/$image")) {
                echo "New image uploaded: $image<br>";
                if ($currentImage && file_exists(__DIR__ . "/../storage/images/$currentImage")) {
                    echo "Deleting previous image: $currentImage<br>";
                    unlink(__DIR__ . "/../storage/images/$currentImage");
                }
    // update with image
                $query = "UPDATE products SET name = :name,quantity = :quantity , description = :description, price = :price, image = :image WHERE id = :id";
                $parameters = [
                    ':name' => $name, ':description' => $description,
                    ':price' => $price, ':image' => $image, ':id' => $id,  ':quantity' => $quantity,
                ];
            } else {// update the inage without it
                $query = "UPDATE products SET name = :name,quantity = :quantity, description = :description, price = :price WHERE id = :id";
                $parameters = [
                    ':name' => $name, ':description' => $description,
                    ':price' => $price, ':id' => $id, ':quantity' => $quantity,
                ];
            }
    
            try {
                $stmt = $pdo->prepare($query);
                $stmt->execute($parameters);
    
           // header('Location: ../index.php'); // Replace 'some_page.php' with the appropriate URL
            // exit;
            echo '<meta http-equiv="refresh" content="0;url=../index.php">';
            // here to redirect to the home page above as i said on the add.php
    
    
    
            } catch (Exception $e) {// error occure
                echo "Error while updating the  product: " . $e->getMessage();
            }
        } catch (Exception $e) {// error occure
            echo "Error occuer!!-->>: " . $e->getMessage();
            exit;
        }
    }
    
