<?php

    require __DIR__ . '/../include/database.php';  // require the database here
    require __DIR__ . '/Product.php';  // require product class here 
    
    if (isset($_GET['id'])) {// if the id have value in it 
        $id = $_GET['id'];//let the id equals t gotten id 
    
        try {// try and catch to handke the errors
        //pdo to select all the product info depend on id
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
            $stmt->bindParam(':id', $id);// bind it
            $stmt->execute();// excute it 
    
            $row = $stmt->fetch(PDO::FETCH_ASSOC);// fetch its values
    
        } catch (\Exception $e) {// exception for error occure 
            echo "Error ocure!!!!-->>>: " . $e->getMessage();
        }
    } else {
        echo "ther is no   product specified!!!!!.";
    }


