<?php
namespace Controller;// name space to avoid class name collisions

use Exception;// this to use the exception
use PDO;// this to use the pdo

require __DIR__ . '/../include/database.php';  // requere the database content here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {//the request method to post
    $name = $_POST['name'];// post the value of name
    $category = $_POST['category'];// post the value of category
    $description = $_POST['description'];// post the value of descroption
    $price = $_POST['price'];// post the value of price
    $rating = $_POST['rating'];// post the value of rating
    $imageTemp = $_FILES['image']['tmp_name'];//the image value as file
    $quantity = $_POST['quantity'];// post the value of quantity

    try {//use try catch to handle the errors
        //insert this values to the database
        $stmt = $pdo->prepare("INSERT INTO products (name, category, description, price, rating, quantity) VALUES (:name, :category, :description, :price, :rating, :quantity)"); //using the pdo prepare
        
        $stmt->execute([
            ':name' => $name,
            ':category' => $category,
            ':description' => $description,
            ':price' => $price,
            ':rating' => $rating,
            ':quantity' => $quantity 
        ]);//excute the data 

        $productId = $pdo->lastInsertId();//initialize the product id to last inserted id

        $newImageName = $productId . '.jpg';
        $newImagePath = "../storage/images/$newImageName";

        if (!empty($imageTemp) && move_uploaded_file($imageTemp, $newImagePath)) {
            $stmt = $pdo->prepare("UPDATE products SET image = :image WHERE id = :id");
            $stmt->execute([
                ':image' => $newImageName,
                ':id' => $productId
            ]);

          // header('Location: ../index.php'); // Replace 'some_page.php' with the appropriate URL
        // exit;
// above i tried the header but it not work but hwre is the syntax note:it worked on the other server the issue fron the cpanale 
            echo '<meta http-equiv="refresh" content="0;url=../index.php">';
            // here the meta that redirect to the home page
        } else {// error in the uploding the image
            echo "Error while uploading  the image!!!.";//print error message
        }
    } catch (Exception $e) {
        echo "Error occuree!!!!!-->>: " . $e->getMessage();// print an error massage
    }
}
?>