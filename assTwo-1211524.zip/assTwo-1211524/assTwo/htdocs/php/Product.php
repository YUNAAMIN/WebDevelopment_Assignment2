<?php

class Product {// this class represents the product class
    public $id;// id of clothes
    public $name;// name of clothes
    public $category;// category of clothes
    public $description;// discription of clothes
    public $price;// price of clothes
    public $rating;// rating of clothes
    public $image;// image of clothes
    public $quantity;// quantity of clothes

    public function __construct($id = 0, $name = '', $category = '', $description = '', $price = 0.0, $rating = 0, $image = '', $quantity = 0) {//argument constructor with initialized value
        $this->id = $id;// id of clothes
        $this->name = $name;// name of clothes
        $this->category = $category;// category of clothes
        $this->description = $description;// descrition of clothes
        $this->price = $price;// price of clothes
        $this->rating = $rating;// rating of clothes
        $this->image = $image;// image of clothes
        $this->quantity = $quantity;// quantity of clothes
    }

    public function displayInTable() {// method to display the table
    echo "
        <tr>
            <td><figure> <img src='storage/images/$this->image' alt='$this->name' width='100'></figure> </td>
            <td><a href='show.php?id=$this->id'>$this->id</a></td>
            <td>$this->name</td>
            <td>$this->category</td>
            <td>$this->price</td>
            <td>$this->quantity</td>
            <td>
                <span>
                    <form action='edit.php' method='get' style='display:inline';>
                        <input type='hidden' name='id' value='$this->id'>
                        <button type='submit'>
                            <img src='storage/images/edit.png' alt='Edit'>
                        </button>
                    </form>
                </span>
                <span>
                    <form action='php/delete.php' method='post' style='display:inline';>
                        <input type='hidden' name='id' value='$this->id'>
                        <button type='submit'>
                            <img src='storage/images/delete.png' alt='Delete'>
                        </button>
                    </form>
                </span>
            </td>
        </tr>
    ";
}// html code for the table that will be displayin in the index.php

    public function displayProductPage() {// this method to display product page
        $desc='';
        $description=explode('.',$this->description);//explode depend on dot .

        for ($i=0 ; $i<sizeof($description)-1 ;$i++){// walk throught discriton

            $desc.="<li>   $description[$i]  </li>";// add discritpn as in list

        }

//echo for the main that will display the product info on it 
        echo "<main>
                <figure>   
                <img src='storage/images/$this->image' width='200' height='300'>
                <figcaption>
                <h2>Product ID: $this->id , $this->name </h2>
                <ul>
                <li><p>Price:  $this->price</p></li>
                <li><p>Category: $this->category </p></li>
                <li><p>Rating: $this->rating /5</p></li>
                </ul>
                <h2>Description:</h2>

                <ul>
        $desc
                </ul>
                </figcaption>
                </figure> 
                </main>";
    }
}




