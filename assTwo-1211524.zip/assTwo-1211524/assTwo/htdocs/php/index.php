<?php

include __DIR__ . "/../include/database.php";// include the database inthis classs

require 'Product.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';// if the search value have then it will be the value oother wize nothing contain in it 
$type = isset($_GET['type']) ? $_GET['type'] : '';// if the type value have then it will be the value oother wize nothing contain in it
$category = isset($_GET['category']) ? $_GET['category'] : '';// if the category value have then it will be the value oother wize nothing contain in it

$query = "SELECT * FROM products WHERE 1=1";// select all from the query
$params = [];// search value

if (!empty($search)) {
    switch ($type) {
        case 'name':// if i select name to filter
            $query .= " AND name LIKE :name";// have name or part of it 
            $params[':name'] = "%$search%";// make search for it 
            break;// break
        case 'price':// if i select price to filter
            $query .= " AND price >= :price";// gat all price greater or equals
            $params[':price'] = $search;// make search for it
            break;// break
        
        default:
             break;// break
    }
}

if (!empty($category)) {// here to compare it with caticory if i want 
    $query .= " AND category LIKE :category";
    $params[':category'] = "%$category%";
}

$stmt = $pdo->prepare($query);// pdo to prepare statement
$stmt->execute($params);// excute then fetch all 
$products = $stmt->fetchAll(PDO::FETCH_FUNC, function ($id, $name, $category, $description, $price, $rating, $image, $quantity) {
    return new Product($id, $name, $category, $description, $price, $rating, $image, $quantity);// return a new product that contains the search
});



