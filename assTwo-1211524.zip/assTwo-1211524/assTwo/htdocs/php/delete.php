<?php
    namespace Controller;
    
    require __DIR__ . '/../include/database.php';  //require the database in class 
    
    $id = isset($_POST['id']) ? $_POST['id'] : null;// if id had valuepost other wise its equals to null
    if (!$id) {// if the id not have id 
        echo "there is no product specified!!!!.";// print out thet the product not specified
        exit;// exit
    }
    
    try {// try and catch to handle the error that occure
            $stmt = $pdo->prepare("SELECT image FROM products WHERE id = :id");//prepareusing pdo
            $stmt->bindParam(':id', $id);// bind the id oarameter
            $stmt->execute();// excute
            $product = $stmt->fetch();// fetch it 
        
            if (!$product) {//if there is no product 
                echo "Product not found.";// print out that there is no product
                exit;//exit
        }
    
        $imageToDelete = $product['image'];//image to delete var 
    
        // pdo that will do sql statement to delete the product
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
        $stmt->bindParam(':id', $id);// bind the value of the id
        $stmt->execute();// excute it
    
        if ($imageToDelete && file_exists(__DIR__ . "../storage/images/$imageToDelete")) {
            unlink(__DIR__ . "../storage/images/$imageToDelete");
        }// if the image wxixst dalete the image 
    
        // header('Location: ../index.php'); // Replace 'some_page.php' with the appropriate URL
        // exit;
        echo '<meta http-equiv="refresh" content="0;url=../index.php">';
        // here to redirect to the home page above as i said on the add.php
    
    } catch (Exception $e) {// catch the error message
        echo "Error while deleting the product!!!--->>: " . $e->getMessage();//print out the error message
    }
    
