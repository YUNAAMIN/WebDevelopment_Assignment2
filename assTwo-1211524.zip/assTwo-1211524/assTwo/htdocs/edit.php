<!-- this part will represent the php code part that is to bring the data from the database to set it in the table and make edit on it -->
<?php

    require __DIR__ . '/include/database.php';// let the database content to be accesable in this class

    $id = null;// initialize the id as anull for the first value
    if (isset($_GET['id'])) {// if the id is gotten and had a value
        $id = $_GET['id'];// let the id value to be the value that bringen
    }
    if (!$id) {//is there is no id selected or choosen 
        echo "There is no product selected or chosen";// print out error message
        exit;// exit the if statement
    }
    try {// use try and catch to handle the errors
        $info = $pdo->prepare("SELECT * FROM products WHERE id = :id");// prepare to select the product detail for specific id choosen
        $info->bindParam(':id', $id);// to pass variable not value
        $info->execute();// excute it
        $product = $info->fetch();// then fetch 
        if (!$product) {// check if there is no product info
            echo "The product cant be found!!!!!!!!!!1";
            exit;// exit the if statement
        }
    } catch (Exception $e) {// here that handle error that nay occure from database pdo
        echo "ERROR OCCURES!!!-->> " . $e->getMessage();
        exit;// exit the if statement
    }

?>


<!-- this part will represent the html code that will check for any changes and edit on the table -->
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>update Product Record Page</title><!--this will represent the title of the page-->
    </head>

    <?php
    include "components/header.php";// include the header here that using include to include it from the page
    ?>

    <body>

        <h2>Products Records:</h2>

        <form method="post" action="php/edit.php?id=<?= htmlspecialchars($id) ?>"  enctype="multipart/form-data"><!--post form that will send the form to edit.php that is in php file-->
        <label for="productName">Product Id:</label><!--label for product id-->
            <input type="text" id="id" name="id" value="<?= htmlspecialchars($product['id']) ?>" disabled><br><br><!--input type text for id and the value of it is id for specific id and                  its disabled-->

            <label for="productName">Product Name:</label><!--label for product name-->
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>"><br><br><!--input type text for name and the value of it is id for specific name-->

            <?php echo htmlspecialchars($product['category'])// to avoid rendarring issues for the html  ?>
            <label for="category">Category:</label><!--label for product category-->
            <select id="category" name="category" disabled><!--combobox to select categories and its disabled to not make changes on it -->
                <option value="" 
                    <?php if (htmlspecialchars($product['category']) == '') {//if its equals '' then its selected
                        echo 'selected';
                        } ?>
                        >Select Category</option><!--option for the catigory-->

                <option value="Formal Shirt"
                    <?php if (htmlspecialchars($product['category']) == 'Formal Shirt') {//if its equals to Formal Shirt then its selected
                        echo 'selected';
                        } ?>
                    >Formal Shirt</option><!--option for the catigory-->

                <option value="Sweater"
                    <?php if (htmlspecialchars($product['category']) == 'Sweater') {//if its equals to Sweater then its selected
                        echo 'selected';
                    } ?>
                    >Sweater</option><!--option for the catigory-->

                <option value="Trousers" 
                    <?php if (htmlspecialchars($product['category']) == 'Trousers') {//if its equals to Trousers then its selected
                        echo 'selected';
                        } ?>
                        >Trousers</option><!--option for the catigory-->

                <option value="Dress" 
                    <?php if (htmlspecialchars($product['category']) == 'Dress') {//if its equals to Dress then its selected
                        echo 'selected';} ?>
                        >Dress</option><!--option for the catigory-->

                <option value="T-shirt" 
                    <?php if (htmlspecialchars($product['category']) == 'T-shirt') {//if its equals to T-shirt then its selected
                        echo 'selected';
                        } ?>
                        >T-shirt</option><!--option for the catigory-->

                <option value="Jeans"
                    <?php if (htmlspecialchars($product['category']) == 'Jeans') {//if its equals to Jeans then its selected
                        echo 'selected';
                        } ?>
                        >Jeans</option><!--option for the catigory-->

                <option value="Skirt" 
                    <?php if (htmlspecialchars($product['category']) == 'Skirt') {//if its equals to Skirt then its selected
                        echo 'selected';
                        } ?>
                        >Skirt</option><!--option for the catigory-->

                <option value="Blouse"
                    <?php if (htmlspecialchars($product['category']) == 'Blouse') {//if its equals to Blouse then its selected
                        echo 'selected';
                        } ?>
                        >Blouse</option><!--option for the catigory-->
            </select>
            <br><br>

            <label for="price">Price:</label><!--label for product price-->
            <input type="number" id="price" name="price" value="<?= htmlspecialchars($product['price']) ?>" ><br><br><!--input type number for name and the value of it is price for                            specific price-->

            <label for="quantity">Quantity:</label><!--label for product quantity-->
            <input type="number" id="quantity" name="quantity" value="<?= htmlspecialchars($product['quantity']) ?>"><br><br><!--input type number for name and the value of it is quantity                     for specific quantity-->

            <label for="rating">Rating:</label><!--label for product rating-->
            <input type="number" id="rating" name="rating" value="<?= htmlspecialchars($product['rating']) ?>"  min="1" max="5" disabled><br><br><!--input type text for name and the value                     of it is rating for specific rating and it will be disabled-->

            <label for="description">Description:</label><!--label for product description-->
            <textarea id="description" name="description" rows="6" cols="50">
                    <?php 
                    echo htmlspecialchars($product['description'])//htmlspecialcharsto avoid html rendarring issues 
                    ?>
        </textarea>
            <br><br>

            <label for="productPhoto">Product Photo:</label><!--lable to the ptoduct photo-->
            <input type="file" id="image" name="image" accept="image/jpeg"><br><br><!--input type file that it will make to choose only jpeg picture only as requered in our assignment-->

            <input type="submit" value="update"><!--input type submit that its value us update to use it to update-->
        </form>

    </body>
        <?php
        include "components/footer.php";// include the footer here that using include to include it from the page
        ?>
    </html>
    </form>
